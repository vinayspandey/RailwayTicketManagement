package com.rtms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LogIN {

	public boolean user_login(String username, String password) {
		try {
			// Get a connection using the DbConnection class
			Connection connection = DbConnection.connect();

			// Validate login
			return validateLogin(connection, username, password);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	private static boolean validateLogin(Connection connection, String username, String password) throws SQLException {
		try {
			String sql = "SELECT username password FROM user WHERE username = ? AND password = ?";
			try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

				preparedStatement.setString(1, username);

				preparedStatement.setString(2, password);

				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					return resultSet.next(); // If a record is found, login is successful
				}
			}
		} finally {
			// Close the connection in a finally block to ensure it is closed even if an
			// exception occurs
			if (connection != null) {
				connection.close();
			}
		}
	}

	public boolean admin_login(String username1, String password1) {
		try {
			// Get a connection using the DbConnection class
			Connection connection = DbConnection.connect();

			// Validate login
			return validateLogin1(connection, username1, password1);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	private static boolean validateLogin1(Connection connection, String username1, String password1)
			throws SQLException {
		try {
			String sql1 = "SELECT admin_name admin_pass FROM admin WHERE admin_name = ? AND admin_pass = ?";
			try (PreparedStatement preparedStatement1 = connection.prepareStatement(sql1)) {

				preparedStatement1.setString(1, username1);

				preparedStatement1.setString(2, password1);

				try (ResultSet resultSet = preparedStatement1.executeQuery()) {
					return resultSet.next(); // If a record is found, login is successful
				}
			}
		} finally {
			// Close the connection in a finally block to ensure it is closed even if an
			// exception occurs
			if (connection != null) {
				connection.close();
			}
		}
	}
}
