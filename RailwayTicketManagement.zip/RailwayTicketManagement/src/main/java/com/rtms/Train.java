package com.rtms;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Train {
	public static void retrieveTrainData() {
		try {
			
	        // Establishing database connection
	        Connection connection = DbConnection.connect();
	        // SQL query to retrieve data
	        String query = "SELECT * FROM rtms.train_data";

            // Creating a PreparedStatement
	        PreparedStatement preparedStatement = connection.prepareStatement(query);

	        // Executing the query
	        ResultSet resultSet = preparedStatement.executeQuery();
            // Displaying the results
	        while (resultSet.next()) {
	                int trainNumber = resultSet.getInt("T_No");
	                String trainName = resultSet.getString("T_Name");
	                String startTime = resultSet.getString("T_sTime");
	                String endTime = resultSet.getString("T_dTime");
	                String startStation = resultSet.getString("T_sStation");
	                String endStation = resultSet.getString("T_dStation");

	                // Displaying data in console
	                System.out.println("----------------------------------------------------------------");
	                System.out.println("| T.N. |  T.Na.  | S.Time | End Time | S.Stat. |End Station|" );
	                System.out.println("|"+ trainNumber+" | " + trainName+"|"+startTime+" | "+endTime+" |"+startStation+" | "+endStation+"|");
	                
	                System.out.println("-----------------------------------------------------------------");
	            }

	            // Closing resources
	            resultSet.close();
	            preparedStatement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
        }
    }
	

	    public static void insertTrainData(int trainNumber, String trainName, String startTime, String endTime, String startStation, String endStation) {
	        try {
	        	Connection connection = DbConnection.connect();
	            // SQL query to insert train data
	            String query = "INSERT INTO train_data (T_No, T_Name, T_sTime, T_dTime, T_sStation, T_dStation) VALUES (?, ?, ?, ?, ?, ?)";

	            // Creating a PreparedStatement
	            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	                // Inserting record
	                preparedStatement.setInt(1, trainNumber);
	                preparedStatement.setString(2, trainName);
	                preparedStatement.setString(3, startTime);
	                preparedStatement.setString(4, endTime);
	                preparedStatement.setString(5, startStation);
	                preparedStatement.setString(6, endStation);

	                int rowsAffected = preparedStatement.executeUpdate();

	                if (rowsAffected > 0) {
	                    System.out.println("Train data inserted successfully!");
	                    retrieveTrainData();
	                } else {
	                    System.out.println("Failed to insert train data. Please try again.");
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

}


