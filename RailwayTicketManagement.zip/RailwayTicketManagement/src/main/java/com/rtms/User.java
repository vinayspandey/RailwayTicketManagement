package com.rtms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User {
	public static void insertUserData(int u_no, String username, String u_name, String adhar_id, String password) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to insert data
			String query = "INSERT INTO user (u_no, username, u_name, adhar_id, password) VALUES (?, ?, ?, ?, ?)";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				// Inserting record
				preparedStatement.setInt(1, u_no);
				preparedStatement.setString(2, username);
				preparedStatement.setString(3, u_name);
				preparedStatement.setString(4, adhar_id);
				preparedStatement.setString(5, password);

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("User Added");
					retrieveUserData(username);
					
					
				} else {
					System.out.println("Failed to book ticket. Please try again.");
				}
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void retrieveUserData(String username) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to retrieve data
			String query = "SELECT u_no,username,u_name,adhar_id FROM user WHERE username = ?";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setString(1, username);

				// Executing the query
				ResultSet resultSet = preparedStatement.executeQuery();

				// Displaying the results
				while (resultSet.next()) {
					
					int u_no = resultSet.getInt("u_no");
					String u_name = resultSet.getString("u_name");
					String adhar_id = resultSet.getString("adhar_id");
					
					

					System.out.println("--------------------------------------");
					System.out.println("User Number :  " + u_no);
					System.out.println("unique USERName : " + username);
					System.out.println("User Name : " + u_name);
					System.out.println("User Adhar Id : " + adhar_id);
					
					
				}
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


}
