package com.rtms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Chart {
	public static void fetchChartData() {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to fetch data from chart and join with train_data
			String query = "SELECT * FROM chart JOIN train_data ON chart.T_No = train_data.T_No";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				// Executing the query
				ResultSet resultSet = preparedStatement.executeQuery();

				// Displaying the results in a tabular format
				System.out.println("---------------------------------------------------------");
				System.out.printf("| %-4s | %-15s | %-10s | %-5s | %-15s | %-15s |\n", "PNR", "Passenger Name",
						"Adhar ID", "Age", "Train Name", "Start Station");
				System.out.println("---------------------------------------------------------");

				while (resultSet.next()) {
					int pnr = resultSet.getInt("PNR");
					String passengerName = resultSet.getString("p_name");
					String adharId = resultSet.getString("p_adhar_id");
					int age = resultSet.getInt("age");
					String trainName = resultSet.getString("T_Name");
					String startStation = resultSet.getString("T_sStation");

					System.out.printf("| %-4d | %-15s | %-10s | %-5d | %-15s | %-15s |\n", pnr, passengerName, adharId,
							age, trainName, startStation);
					System.out.println("---------------------------------------------------------");

				}
				connection.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
