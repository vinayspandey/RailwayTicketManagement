package com.rtms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TicketBookingCancel {

	public static void bookTicket(String p_name, String p_adhar_id, int age, int T_No, String username) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to insert data
			String query = "INSERT INTO chart (p_name, p_adhar_id, age, T_No ,username) VALUES (?, ?, ?, ?, ?)";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				// Inserting record
				preparedStatement.setString(1, p_name);
				preparedStatement.setString(2, p_adhar_id);
				preparedStatement.setInt(3, age);
				preparedStatement.setInt(4, T_No);
				preparedStatement.setString(5, username);

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("Ticket booked successfully!");
					retrieveDataByPassengerAdharID(p_adhar_id);
					connection.close();
				} else {
					System.out.println("Failed to book ticket. Please try again.");
				}
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void retrieveDataByPassengerAdharID(String p_adhar_id) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to retrieve data
			String query = "SELECT * FROM chart WHERE p_adhar_id = ?";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setString(1, p_adhar_id);

				// Executing the query
				ResultSet resultSet = preparedStatement.executeQuery();

				// Displaying the results
				while (resultSet.next()) {
					int PNR = resultSet.getInt("PNR");
					String pn = resultSet.getString("p_name");
					String paID = resultSet.getString("p_adhar_id");
					int age1 = resultSet.getInt("age");
					int trainNumber = resultSet.getInt("T_No");
					String username = resultSet.getString("username");

					System.out.println("--------------------------------------");
					System.out.println("PNR: " + PNR);
					System.out.println("Passenger Name: " + pn);
					System.out.println("Passenger Adhar Id: " + paID);
					System.out.println("Passenger Age: " + age1);
					System.out.println("Train number: " + trainNumber);
					System.out.println("Railway autharised user :  " + username);

				}
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void showTicketCheckPNR(int pnr) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to retrieve data
			String query = "SELECT * FROM chart JOIN train_data ON chart.T_No = train_data.T_No WHERE chart.pnr = ?";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setInt(1, pnr);

				// Executing the query
				ResultSet resultSet = preparedStatement.executeQuery();

				// Displaying the results
				while (resultSet.next()) {
					int PNR = resultSet.getInt("PNR");
					String pn = resultSet.getString("p_name");
					String paID = resultSet.getString("p_adhar_id");
					int age1 = resultSet.getInt("age");
					String username = resultSet.getString("username");
					int trainNumber = resultSet.getInt("T_No");
					String trainName = resultSet.getString("T_Name");
					String startTime = resultSet.getString("T_sTime");
					String endTime = resultSet.getString("T_dTime");
					String startStation = resultSet.getString("T_sStation");
					String endStation = resultSet.getString("T_dStation");

					System.out.println("--------------------------------------");
					System.out.println("PNR: " + PNR);
					System.out.println("Passenger Name: " + pn);
					System.out.println("Passenger Adhar Id: " + paID);
					System.out.println("Passenger Age: " + age1);
					System.out.println("Railway autharised user :  " + username);
					System.out.println("----------------------------------------------------------------");
					System.out.println("| T.N. |  T.Na.  | S.Time | End Time | S.Stat. |End Station|");
					System.out.println("|" + trainNumber + " | " + trainName + "|" + startTime + " | " + endTime + " |"
							+ startStation + " | " + endStation + "|");

					System.out.println("-----------------------------------------------------------------");

				}
				connection.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void cancelTicket(int pnr) {
		System.out.println("Do you want to cancel the ticket?\n 1 : yes\n 2 : no");
		try (Connection connection = DbConnection.connect()) {
			// SQL query to delete data
			String query = "DELETE FROM chart WHERE PNR =  ?";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setInt(1, pnr);

				// Executing the update (DELETE) query
				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("Ticket canceled successfully.\n collect your money.");

					connection.close();
				} else {
					System.out.println("Ticket not found. Please check the PNR and try again.");
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	

}
