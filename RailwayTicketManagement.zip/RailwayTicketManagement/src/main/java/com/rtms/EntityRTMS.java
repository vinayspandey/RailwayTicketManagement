package com.rtms;


public class EntityRTMS {
    public static void exit() throws InterruptedException {
        System.out.print("Exiting System");
        int i = 10;
        while (i != 0) {
            System.out.print(".");
            Thread.sleep(500);
            i--;
        }
        System.out.println();
        System.out.println("Thank You For Using Railway Ticket Reservation System!!!");
    }
    public static void waiting() throws InterruptedException {
        int i = 20;
        while (i != 0) {
            System.out.print("*********************************************");
            i--;
        }
        System.out.println();
 
    }
}

