package com.rtms;

public class MenuMassage {
	public static void userMenu() {
		String um= "\nEnter the selection \n 1 : Book Ticket \n"
				+ " 2 : Show ticket & Check PNR \n 3 : Cancel Ticket \n 4: Show Trains \n 5 : Exit \n Enter selection : ";
		System.out.println(um);
	}
	public static void adminMenu() {
		String um= "\nEnter the selection \n 1 : show chart \n"
				+" 2 : Insert Trains \n 3 : Search Autherised user \n 4 : exit";
		System.out.println(um);
	}

}
