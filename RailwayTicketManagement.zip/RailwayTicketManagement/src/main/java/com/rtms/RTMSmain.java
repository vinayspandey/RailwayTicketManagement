package com.rtms;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class RTMSmain {
	public static void main(String[] args) throws SQLException, InterruptedException {
		Connection con = DbConnection.connect();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Wellcome to RTMS");
		System.out.print(
				"Tell me -Who are you \n 1 : User \n 2 : Admin \n 3: Create an account (user/admin) \nEnter  your selection : ");
		int s1 = scanner.nextInt();
		EntityRTMS.waiting();
		switch (s1) {
		case 1: {
			System.out.println("-WELCOME USER INTERFACE-");
			System.out.print("Enter username:");
			String username = scanner.next();
			System.out.print("Enter password:");
			String password = scanner.next();
			// Instantiate the JdbcConsoleLogin class
			LogIN l = new LogIN();
			// Call the login method to check the login credentials
			if (l.user_login(username, password)) {
				System.out.println("\n Login successful \n HELLO, " + username);
				boolean b = true;
				while (b) {
					MenuMassage.userMenu();
					int s11 = scanner.nextInt();
					EntityRTMS.waiting();
					switch (s11) {
					case 1: {
						EntityRTMS.waiting();
						System.out.println("you are selected \n Book Ticket");
						System.out.print("Passenger Name:");
						String p_name = scanner.next();
						System.out.print("Passenger AdharID:");
						String p_adhar_id = scanner.next();
						System.out.print("Passenger age:");
						int age = scanner.nextInt();
						Train.retrieveTrainData();
						System.out.print("train number:");
						int T_No = scanner.nextInt();
						System.out.println("Payment 100 Rupay ");
						int pay = scanner.nextInt();
						if (pay == 100) {
							int i = 5;
							while (i != 0) {
								System.out.print(".");
								Thread.sleep(500);
								i--;
							}
							System.out.println("Payment successful!");
							TicketBookingCancel.bookTicket(p_name, p_adhar_id, age, T_No, username);
						} else
							System.out.println("Payment Failed! Try again");
						b = true;
					}
						break;
					case 2: {
						EntityRTMS.waiting();
						System.out.println("Show ticket & Check PNR");
						System.out.println("Enter PNR : ");
						int pnr = scanner.nextInt();
						TicketBookingCancel.showTicketCheckPNR(pnr);
						EntityRTMS.waiting();
					}
						break;
					case 3: {
						EntityRTMS.waiting();
						System.out.println("Show ticket & Check PNR");
						System.out.println("Enter PNR : ");
						int pnr = scanner.nextInt();
						TicketBookingCancel.showTicketCheckPNR(pnr);
						System.out.println("do you wnat to cancel ticket\n 1 : yes\n 2 : no");
						int s31 = scanner.nextInt();
						if (s31 == 1) {
							TicketBookingCancel.cancelTicket(pnr);
						} else {
							System.out.println("ok!");
						}
						EntityRTMS.waiting();
					}
						break;
					case 4: {
						EntityRTMS.waiting();
						System.out.println("Train Data.....");
						Train.retrieveTrainData();
						EntityRTMS.waiting();
					}
						break;
					case 5: {
						EntityRTMS.waiting();
						EntityRTMS.exit();
						EntityRTMS.waiting();
						b = false;
					}

					}
				}
			} else {
				System.out.println("Login failed");
			}
		}
			break;
		case 2: {
			EntityRTMS.waiting();
			System.out.println("-WELCOME Admin INTERFACE-");
			System.out.print("Enter username:");
			String username1 = scanner.next();
			System.out.print("Enter password:");
			String password1 = scanner.next();
			// Instantiate the JdbcConsoleLogin class
			LogIN l1 = new LogIN();

			// Call the login method to check the login credentials
			if (l1.admin_login(username1, password1)) {
				System.out.println("Login successful \n HELLO, " + username1);
				boolean b = true;
				while (b) {
					MenuMassage.adminMenu();
					int s21 = scanner.nextInt();
					switch (s21) {
					case 1: {
						EntityRTMS.waiting();
						System.out.println("Chart");
						Chart.fetchChartData();
						EntityRTMS.waiting();
					}
						break;
					case 2: {
						EntityRTMS.waiting();
						System.out.println("Insert Train detail");
						System.out.print("Tarin no : ");
						int trainNumber = scanner.nextInt();
						System.out.print("Train Name : ");
						String trainName = scanner.next();
						System.out.print("Start Time :");
						String startTime = scanner.next();
						System.out.print("Departure Time :");
						String endTime = scanner.next();
						System.out.print("Start Station :");
						String startStation = scanner.next();
						System.out.print("Departure Station :");
						String endStation = scanner.next();
						Train.insertTrainData(trainNumber, trainName, startTime, endTime, startStation, endStation);
						EntityRTMS.waiting();

					}
						break;
					case 3: {
						EntityRTMS.waiting();
						System.out.print("Search Autherised user in rtms databaes. \nEnter the username : ");
						String username = scanner.next();
						User.retrieveUserData(username);
						EntityRTMS.waiting();
					}
						break;
					case 4:{
						EntityRTMS.waiting();
						EntityRTMS.exit();
						EntityRTMS.waiting();
						b = false;
					}
					}break;
				}

			} else {
				System.out.println("Login failed");
			}
		}
			break;
		case 3: {
			EntityRTMS.waiting();
			System.out.println("Enter 1 for create user account & Enter 2 for create admin acount : ");
			int se1 = scanner.nextInt();
			EntityRTMS.waiting();
			switch (se1) {
			case 1: {
				EntityRTMS.waiting();
				System.out.print("Enter user id : ");
				int u_no = scanner.nextInt();
				System.out.print("Enter unique username : ");
				String username = scanner.next();
				System.out.print("Enter user name : ");
				String u_name = scanner.next();
				System.out.print("Enter  user Adhar ID: ");
				String adhar_id = scanner.next();
				System.out.print("Entter user Password : ");
				String password = scanner.next();
				User.insertUserData(u_no, username, u_name, adhar_id, password);
				EntityRTMS.waiting();
			}
				break;
			case 2: {
				EntityRTMS.waiting();
				System.out.print("admin unique username : ");
				String admin_name = scanner.next();
				System.out.print("admin username password : ");
				String admin_pass = scanner.next();
				Admin.insertAdminData(admin_name, admin_pass);
				EntityRTMS.waiting();
			}
				break;
			}

		}

		}
		scanner.close();
		con.close();
	}

}
