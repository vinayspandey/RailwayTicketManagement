package com.rtms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Admin {
	public static void insertAdminData(String admin_name,String admin_pass) {
		try (Connection connection = DbConnection.connect()) {
			// SQL query to insert data
			String query = "INSERT INTO admin (admin_name, admin_pass) VALUES (?, ?)";

			// Creating a PreparedStatement
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				// Inserting record
				
				preparedStatement.setString(1, admin_name);
				preparedStatement.setString(2, admin_pass);
				

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("Admin Added");
					
					
					connection.close();
				} else {
					System.out.println("Failed to book ticket. Please try again.");
				}
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}

